#pragma once

#define SIMU_X 2
#define SIMU_Y 6

void init_simu_renderer();

void draw_simu();