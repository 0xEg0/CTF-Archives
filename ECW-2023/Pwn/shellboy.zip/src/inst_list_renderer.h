#pragma once

void init_inst_list_renderer();

void draw_inst_list();
void draw_inst_cursor();
void draw_inst_repeat();